-- @file $Id: install.mysql.utf8.sql 1.7 2012-06-28 00:00:00 Luiz Felipe Weber $
-- @package Analytics
-- @version 1.7
-- @copyright	Copyright © 2012 - All rights reserved.
-- @license	GNU General Public License v2.0
--
-- Analytics table(s) definition
--
-- --------------------------------------------------------


