<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    </head>
    <style type="text/css">
        body {
           font-size: 11px;
        }
        body, td, th {
           font-family: Arial,Helvetica,sans-serif;
           font-size: 11px;
           font: 11px arial;
        }
    </style>
    <body>
    <table border="0" cellspacing="0" cellpadding="0" width="600" align="center">
    <tbody>
    <tr>
    <td>
    <table border="0" cellspacing="0" cellpadding="0" width="100%">
    <tbody>
    <tr>
    <td><a href="http://www.webgenium.com.br" target="_blank"><img src="http://www.webgenium.com.br/imagens/logoWebgenium.png" border="0" alt="Webgenium" width="264" height="77" /></a></td>
    <td><a href="http://www.webgenium.com.br"><img src="http://www.webgenium.com.br/imagens/menuDesenvSitesWeb.png" border="0" alt="Desenvolvimento de Sites e Sistemas Web" width="126" height="77" /></a></td>
    <td><a href="http://www.webgenium.com.br"><img src="http://www.webgenium.com.br/imagens/menuRegistroDominios.png" border="0" alt="Registro de Dom&iacute;nios" width="104" height="77" /></a></td>
    <td><a href="http://www.webgenium.com.br"><img src="http://www.webgenium.com.br/imagens/menuHospedagem.png" border="0" alt="Hospedagem" width="106" height="77" /></a></td>
    </tr>
    </tbody>
    </table>
    </td>
    </tr>
    <tr>
    <td style="padding-left:14px; padding-right:14px; padding-bottom:5px; padding-top:5px;">
    <table border="0" cellspacing="0" cellpadding="0" width="100%">
    <tbody>
    <tr>
    <td style="background:url(http://www.webgenium.com.br/imagens/bgAssunto.png); background-repeat:no-repeat; background-position:left; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif; font-size:20px; font-weight:bold; padding:8px;">Veja as Estat�sticas de seu site de <b style='color: #456FFF'><?php echo date('Y-m-d',strtotime('1 month ago')); ?></b> a <b style='color: #456FFF'><?php echo date('d/m/Y'); ?></b><br/><div style='color: #7F7F7F;font-size: 12px; font: 12px arial; font-family: arial;'>http://<?=$_SERVER['HTTP_HOST']?></div></td>
    <td width="229"><img src="http://www.webgenium.com.br/imagens/iconAtendimento.png" alt="Atendimento" width="229" height="98" /></td>
    </tr>
    <tr>
    <td style="font-family:Arial, Helvetica, sans-serif; font-size:12px; padding:6px; border:1px solid #dfdfdf; border-top:0px;" colspan="2" height="200" valign="top">
    <p><?php echo $this->conteudo_email; ?></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>Equipe Webgenium System<br/>
    Solu&ccedil;&otilde;es Inteligentes Via Web</p>
    </td>
    </tr>
    </tbody>
    </table>
    </td>
    </tr>
    <tr>
    <td><img src="http://www.webgenium.com.br/imagens/rodape.png" alt="Rodape" width="600" height="34" /></td>
    </tr>
    </tbody>
    </table>
    </body>
</html>